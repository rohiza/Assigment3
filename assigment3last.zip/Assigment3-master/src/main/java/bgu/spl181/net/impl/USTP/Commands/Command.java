package bgu.spl181.net.impl.USTP.Commands;

public interface Command {

    void execute();
}
